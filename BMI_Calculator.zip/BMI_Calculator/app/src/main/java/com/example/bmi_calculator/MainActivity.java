package com.example.bmi_calculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    EditText edtWeight, edtHeight;
    Button btnCalculate;
    TextView txtResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtWeight = findViewById(R.id.edtWeight);
        edtHeight = findViewById(R.id.edtHeight);
        btnCalculate = findViewById(R.id.btnCalculate);
        txtResult = findViewById(R.id.txtResult);

        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String weightStr = edtWeight.getText().toString().trim();
                String heightStr = edtHeight.getText().toString().trim();

                if (weightStr.isEmpty() || heightStr.isEmpty()) {
                    txtResult.setText("Please enter both weight and height");
                    return;
                }

                try {
                    float weight = Float.parseFloat(weightStr);
                    float heightCm = Float.parseFloat(heightStr);
                    float heightM = heightCm / 100;

                    float bmi = weight / (heightM * heightM);

                    String category;
                    if (bmi < 18.5)
                        category = "Underweight";
                    else if (bmi < 24.9)
                        category = "Normal weight";
                    else if (bmi < 29.9)
                        category = "Overweight";
                    else
                        category = "Obese";

                    String result = String.format("BMI: %.2f\nCategory: %s", bmi, category);
                    txtResult.setText(result);

                } catch (NumberFormatException e) {
                    txtResult.setText("Invalid input. Please enter valid numbers.");
                }
            }
        });
    }
}
